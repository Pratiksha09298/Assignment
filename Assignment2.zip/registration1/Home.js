import React from 'react';
import { StyleSheet, View, Button,Text } from 'react-native';

export default class Home extends React.Component{
  static navigationOptions = {
        title: 'Home',
    };

    render() {

        const { navigate } = this.props.navigation;

        return (
            <View style={styles.container}>
            <Text> Press the button & Go to Registration</Text>

                <Button
                    title="Register"
                    onPress={() => navigate(
                        'Register', ('Register' )
                    )}
                />
          </View>
        );

    }

}

const styles = StyleSheet.create({
    container: {
      backgroundColor:'pink',
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
        
    }
});