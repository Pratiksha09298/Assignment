import React from 'react';
import { StyleSheet, View, TextInput,Text, Button,ImageBackground,TouchableOpacity} from 'react-native';
import {createStackNavigator} from 'react-navigation';
import { createAppContainer } from 'react-navigation';


export default class Register extends React.Component
{
  constructor(props)
  {
      super(props);
      this.state={username:" ",email:" ",id:" "};

  }
  render(){
    return(
      <View style={styles.Register}>
        <Text style={styles.header}>Registration</Text>

        <TextInput style={styles.textinput}  placeholder="ID" returnKeyType="next"
        onSubmitEditing={()=>this.pass}
        underlineColorAndroid={"transparent"}
        onChangeText={id=>this.setState({id})}/>


        <TextInput style={styles.textinput} placeholder="Name" underlineColorAndroid={"transparent"} onChangeText={username=>this.setState({username})}/>

        <TextInput style={styles.textinput} placeholder="Email ID"  underlineColorAndroid=           {"transparent"}  onChangeText={email=>this.setState({email})}/>

        <Button title="Click Me" onPress={()=>this.props.navigation.navigate("Welcome",{name:this.state.username,id:this.state.id, email:this.state.email})}>
           <Text style={styles.btntext} >Register</Text>
        </Button>
      </View>
    )
  }
}

const styles=StyleSheet.create({
  Register:{
      alignSelf:"stretch",
      backgroundColor:'pink'
  },
  header:{
    fontSize:24,
    color:"black",
    paddingBottom:10,
    marginBottom:40,
    borderBottomColor:"#199",
    borderBottomWidth:1
  },
  textinput:{
    alignSelf:"stretch",
    height:40,
    marginBottom:30,
    color:"black",
    borderBottomColor:"gray",
    borderBottomWidth:1
  },
  button:{
    alignSelf:"stretch",
    alignItems:"center",
    padding:20,
    backgroundColor:"#199",
    marginTop:30 
    },
    btntext:{
      color:"#fff",
      fontWeight:"bold"
    }
})