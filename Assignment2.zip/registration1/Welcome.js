import React from 'react';
import { StyleSheet, View, TextInput,Text, Button,ImageBackground,TouchableOpacity} from 'react-native';

export default class Welcome extends React.Component{
  render(){
    return(
      <View style={styles.container}>
        <Text style={styles.header}>Registration</Text>
          <Text >The ID is {this.props.navigation.state.params.id}</Text>
           <Text >The Name is {this.props.navigation.state.params.name}</Text>
            <Text >The Email ID is {this.props.navigation.state.params.email}</Text>
      </View>
    )
  }
}


const styles=StyleSheet.create({
  container:{
      alignSelf:"stretch",
      background:'pink'
  },
  header:{
    fontSize:24,
    color:"black",
    paddingBottom:10,
    marginBottom:40,
    borderBottomColor:"#199",
    borderBottomWidth:1
  }
  
  })