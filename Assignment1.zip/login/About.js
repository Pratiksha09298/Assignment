import React from 'react';
import {View,Text}from 'react-native';

export default class About extends React.components{
  render()
  {
  return(
    <View>
    <Text>This is About Page</Text>
    </View>
  );
  }
} 